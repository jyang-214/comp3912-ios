//
//  ImageViewController.swift
//  ViewBasics
//
//  Created by Jacky Yang on 2023-06-03.
//

import Foundation
import UIKit


class ImageViewController:UIViewController{
    
    var tintColor: UIColor!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = tintColor
        
    }
}
