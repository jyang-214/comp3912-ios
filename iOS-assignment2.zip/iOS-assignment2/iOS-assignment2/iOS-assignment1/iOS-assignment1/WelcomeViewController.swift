//
//  WelcomeViewController.swift
//  iOS-assignment1
//
//  Created by Jacky Yang on 2023-06-12.
//

import UIKit

class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Login(_ sender: Any) {
        print("Log in has been clicked.")
    }
    
    @IBAction func SignUp(_ sender: Any) {
        print("Sign Up has been clicked.")
    }
}
