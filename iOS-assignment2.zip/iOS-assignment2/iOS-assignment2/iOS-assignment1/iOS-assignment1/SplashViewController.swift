//
//  ViewController.swift
//  iOS-assignment1
//
//  Created by Jacky Yang on 2023-05-12.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
}

