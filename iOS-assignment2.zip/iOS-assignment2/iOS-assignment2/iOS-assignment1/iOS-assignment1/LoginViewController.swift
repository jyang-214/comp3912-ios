//
//  LoginViewController.swift
//  iOS-assignment1
//
//  Created by Jacky Yang on 2023-06-12.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
}
